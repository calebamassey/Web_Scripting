var car_array = new Array("Honda", "BMW", "Toyota");


for (var i = 0; i < car_array.length; i++) {

	document.write(car_array[i] + "<br>");

}